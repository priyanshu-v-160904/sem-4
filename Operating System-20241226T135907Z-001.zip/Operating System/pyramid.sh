\echo "enter the no"
read x

for ((i=1;i<=x;i++))
do 
	for ((j=x;j>i;j--))
	do	
	printf " "
	done
	for ((k=1;k<=((2*i-1));k++))
	do
	printf "*"
	done
	printf "\n"
	
done
for ((a=x;a>=1;a--))
do
	for ((z=x;z>a;z--))
	do
	printf " "
	done
	for ((b=((2*a-1));b>=1;b--))
	do
	printf "*"
	done

	printf "\n"
done
