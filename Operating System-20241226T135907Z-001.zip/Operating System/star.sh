echo "enter the no"
read n
for ((i=0;i<n+1;i++))
do
	for ((j=1;j<=i;j++))			
	do
	printf "x"
	done
	printf "\n"
done
