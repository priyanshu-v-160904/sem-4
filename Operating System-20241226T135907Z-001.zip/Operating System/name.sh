echo "enter the no"
read n
for ((i=0;i<n;i++))
do 
echo "it's me"
done

