echo "enter the number"
read  a
n=1
x=1
while ((n<=a))
	do
		while ((x<=n))
		do
		printf "*"
		((x=x+1))
		done
	printf "\n"
	((n=n+1)) 
	done		
