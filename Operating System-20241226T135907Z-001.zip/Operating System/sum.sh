echo "enter the digit"
read a
sum=0
while ((a>0))
	do
		((sum=sum+a))
		((a=a-1))
	done
echo "sum is $sum"	
